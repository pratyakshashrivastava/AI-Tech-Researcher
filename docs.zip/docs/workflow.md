# Workflow

## Step 1 — Search

**Purpose:** Find and verify relevant sources.

Suggested configuration:

```text
Find and verify relevant sources for the user's question.
Prioritize authoritative, recent, and relevant sources.
Collect enough information to answer every part of the user's request.
Do not stop after finding only one or two sources when more evidence is needed.
```

## Step 2 — Summarize

**Purpose:** Turn gathered information into a complete answer.

Suggested configuration:

```text
Synthesize the gathered information into a complete answer.
Follow all applicable instructions in the system prompt and answer every part of the user's question.

Use clear Markdown headings, bullet points, numbered lists, and tables when useful.
Include definitions, explanations, examples, comparisons, advantages, disadvantages,
applications, and a final summary whenever relevant.

Never stop in the middle of a section, table, sentence, or requested topic.
Always complete the answer and end with a clearly labeled Summary section.

Do not use HTML tags such as <br>.
```

## Tool

- Web Search

The web search tool is used for current or source-backed research.
