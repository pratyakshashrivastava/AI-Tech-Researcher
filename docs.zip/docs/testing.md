# Testing

The agent is tested with questions from different categories rather than relying on a single example.

## Test cases

### 1. Technical definition
**Question:** Define DSA and explain the different types of data structures.

Expected:
- Definition
- Main categories
- Examples
- Clear summary

### 2. Software engineering
**Question:** Explain SDLC and compare its models.

Expected:
- SDLC definition
- Phases
- Models
- Comparison
- Advantages
- Disadvantages
- Applications
- Summary

### 3. AI concept
**Question:** Explain Retrieval-Augmented Generation (RAG).

Expected:
- Definition
- Workflow
- Applications
- Advantages
- Limitations
- Recent developments when available
- Summary

### 4. Comparison
Ask the agent to compare two or more technologies.

Expected:
- Common comparison criteria
- Clear table where useful
- Pros/cons
- Recommendation or takeaway when appropriate

## Evaluation checklist

- [ ] Answers the entire question
- [ ] Does not stop mid-answer
- [ ] Uses clear headings
- [ ] Uses tables when comparison benefits from one
- [ ] Includes advantages and disadvantages when relevant
- [ ] Ends with a Summary
- [ ] Uses sources appropriately for web-based claims
- [ ] Avoids HTML tags such as `<br>`
- [ ] Clearly communicates uncertainty when evidence is weak
