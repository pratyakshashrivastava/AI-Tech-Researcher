# Improvement Log

## Initial version

The first version used a Research template with:
- Web Search
- Search workflow step
- Summarize workflow step

## Observed issue

Testing with an SDLC question showed that the agent could begin a detailed answer but sometimes:
- omitted disadvantages,
- omitted a final summary,
- or stopped before completing the requested comparison.

## Improvement

The system prompt and workflow were strengthened with explicit completeness requirements.

### Changes

- Added mandatory sections for explanatory questions.
- Added an explicit Advantages section.
- Added an explicit Disadvantages/Limitations section.
- Added a mandatory final Summary.
- Added instructions not to stop in the middle of an answer.
- Added clearer search instructions.
- Added fallback behavior when web search is unavailable.
- Added a testing checklist.

## Next improvements

- Evaluate multiple versions against the same fixed test set.
- Improve source selection and source quality.
- Add structured output fields if supported.
- Measure response completeness and consistency.
